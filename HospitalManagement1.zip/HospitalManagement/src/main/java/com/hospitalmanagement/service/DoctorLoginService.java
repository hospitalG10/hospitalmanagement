package com.hospitalmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.dao.DoctorLoginRepository;
import com.hospitalmanagement.model.DoctorLogin;

@Service
public class DoctorLoginService {
	
@Autowired
	 DoctorLoginRepository doctorloginrepository;

	 public DoctorLogin validateDoctorLogin(DoctorLogin doctorlogin) {
		 DoctorLogin dl= doctorloginrepository.validateDoctorLogin(doctorlogin.getD_id(), doctorlogin.getD_password());
		 return dl;
	 }
}