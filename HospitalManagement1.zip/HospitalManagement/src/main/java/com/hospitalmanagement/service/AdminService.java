package com.hospitalmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.dao.AdminRepository;
import com.hospitalmanagement.model.Admin;



@Service
public class AdminService {

	@Autowired
	AdminRepository adminRepository;

	public Admin validateUser(Admin user) {
		Admin u=adminRepository.validateUser(user.geta_id(),user.getPassword());
		
		return u;
	}
	
}
