package com.hospitalmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.model.Invoice;
import com.hospitalmanagement.dao.InvoiceRepository;

@Service
public class InvoiceServices {
@Autowired
InvoiceRepository InvoiceRepository;
//to save or download
public void save(Invoice invoice) {
	InvoiceRepository.save(invoice);
}
// to view the invoice
public List<Invoice> listAll(){   
	return InvoiceRepository.findAll();
}
public Invoice saveInvoice(Invoice i) {
	// TODO Auto-generated method stub
	return null;
}

}

