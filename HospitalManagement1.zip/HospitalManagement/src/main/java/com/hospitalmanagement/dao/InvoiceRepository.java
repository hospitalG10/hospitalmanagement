
package com.hospitalmanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hospitalmanagement.model.Invoice;

public interface InvoiceRepository extends JpaRepository<Invoice,Integer> {

}
