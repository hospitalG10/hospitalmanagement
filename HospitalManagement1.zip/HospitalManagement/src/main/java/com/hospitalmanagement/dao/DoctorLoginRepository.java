package com.hospitalmanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hospitalmanagement.model.DoctorLogin;

public interface DoctorLoginRepository extends JpaRepository<DoctorLogin, String> {
	@Query("SELECT dl FROM DoctorLogin dl WHERE dl.d_id =?1 and dl.d_password=?2")
	
	public DoctorLogin validateDoctorLogin(int d_id , String d_password);

}
