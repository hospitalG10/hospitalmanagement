package com.hospitalmanagement.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin")
public class Admin {
	@Id
	@Column(name="a_id")
	private int a_id;
	@Column(name="pwd")
	private String password;

	public int geta_id() {
		return a_id;
	}

	public void seta_id(int a_id) {
		this.a_id = a_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {  
		this.password = password;
	}

}

