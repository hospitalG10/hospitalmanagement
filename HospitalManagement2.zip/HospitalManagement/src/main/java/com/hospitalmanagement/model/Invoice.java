package com.hospitalmanagement.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="invoice")


public class Invoice {

	@Id
	@GeneratedValue
	
	@Column(name="IN_ID ")
	private int in_id;
	@Column(name="AP_ID ")
	private int ap_id ;
	@Column(name="P_ID ")
	private int p_id;
	@Column(name="P_ANAME")
	private String p_aname;
	@Column(name="P_AMID ")
	private String p_amid;
	@Column(name="GENDER  ")
	private String gender;
	@Column(name=" D_ID")
	private int d_id;
	@Column(name="IN_DATE ")
	@Temporal(TemporalType. DATE)
	private Date in_date  ;
	@Column(name="IN_TIME ")
	private String in_time ;
	
	
	public Invoice(){
}


	public Invoice(int in_id, int ap_id, int p_id, String p_aname, String p_amid, String gender, int d_id, Date in_date,
			String in_time) {
		super();
		this.in_id = in_id;
		this.ap_id = ap_id;
		this.p_id = p_id;
		this.p_aname = p_aname;
		this.p_amid = p_amid;
		this.gender = gender;
		this.d_id = d_id;
		this.in_date = in_date;
		this.in_time = in_time;
	}


	public int getIn_id() {
		return in_id;
	}


	public void setIn_id(int in_id) {
		this.in_id = in_id;
	}


	public int getAp_id() {
		return ap_id;
	}


	public void setAp_id(int ap_id) {
		this.ap_id = ap_id;
	}


	public int getP_id() {
		return p_id;
	}
}


