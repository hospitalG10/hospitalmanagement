package com.hospitalmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.dao.PatientLoginRepository;
import com.hospitalmanagement.model.PatientLogin;

@Service
public class PatientLoginService {
	
@Autowired
	 PatientLoginRepository patientloginrepository;

	 public PatientLogin validatePatientLogin(PatientLogin patientlogin) {
		 PatientLogin pl= patientloginrepository.validatePatientLogin(patientlogin.getP_id(),patientlogin.getP_password());
		 return pl;
	 }
}

